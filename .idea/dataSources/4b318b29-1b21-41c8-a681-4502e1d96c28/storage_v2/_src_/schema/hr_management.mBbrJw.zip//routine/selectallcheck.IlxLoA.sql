create procedure selectAllCheck()
  BEGIN
SELECT employee_no,check_d,checkin,checkout,check_status FROM chck;
END;

