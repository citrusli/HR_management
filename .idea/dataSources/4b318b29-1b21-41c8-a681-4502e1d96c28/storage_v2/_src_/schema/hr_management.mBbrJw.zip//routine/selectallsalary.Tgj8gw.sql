create procedure selectAllSalary()
  BEGIN
SELECT employee_no,define,basic_salary,post_salary,insurance,allowance,pension FROM salary;
END;

