create procedure selectAllPost()
  BEGIN
SELECT post_no,post_name,post_salary,work_content FROM post;
END;

