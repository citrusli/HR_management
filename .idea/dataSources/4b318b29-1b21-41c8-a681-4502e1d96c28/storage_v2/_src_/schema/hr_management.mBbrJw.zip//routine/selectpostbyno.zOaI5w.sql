create procedure selectPostByNo(IN postno char(2))
  BEGIN
SELECT post_no,post_name,post_salary,work_content FROM post WHERE post_no = postno;
END;

