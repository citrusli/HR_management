create procedure selectAllDepart()
  BEGIN
SELECT department_no,department_name,manager_no,work_place,higher_department,work_content FROM department;
END;

