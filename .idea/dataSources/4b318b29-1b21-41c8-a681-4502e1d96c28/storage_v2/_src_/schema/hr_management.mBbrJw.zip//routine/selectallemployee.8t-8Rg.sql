create procedure selectAllEmployee()
  BEGIN
SELECT employee_no,employee_name,employee_gender,employee_age,employee_status,employee_tel,pass FROM employee;
END;

