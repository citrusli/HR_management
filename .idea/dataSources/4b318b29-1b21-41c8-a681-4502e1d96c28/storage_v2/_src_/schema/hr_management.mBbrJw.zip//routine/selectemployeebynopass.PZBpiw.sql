create procedure selectEmployeeByNoPass(IN in_no char(6), IN pas varchar(40))
  BEGIN
SELECT employee_name FROM employee WHERE employee_no=in_no AND password=pas;
END;

