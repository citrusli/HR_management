create procedure selectDepartByNo(IN in_no varchar(2))
  BEGIN
SELECT department_name,manager_no,higher_department,work_place,work_content FROM department WHERE department_no=in_no;
END;

