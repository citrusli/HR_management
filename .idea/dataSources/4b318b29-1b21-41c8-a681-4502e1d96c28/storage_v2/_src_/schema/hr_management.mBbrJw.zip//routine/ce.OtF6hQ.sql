create procedure ce(IN ec char(2))
  BEGIN
SELECT department_name FROM department WHERE department_no = ec;
END;

