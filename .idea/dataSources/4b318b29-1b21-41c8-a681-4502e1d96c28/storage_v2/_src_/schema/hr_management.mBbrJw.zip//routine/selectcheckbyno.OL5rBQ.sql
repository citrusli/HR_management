create procedure selectCheckByNo(IN in_no char(6))
  BEGIN
SELECT check_d,checkin,checkout,check_status  FROM chck WHERE employee_no=in_no;
END;

