create procedure selectAllRecord()
  BEGIN
SELECT employee_no,birth_date,nation,birth_place,ID,associate_degree,enter_date,address,education,notes FROM record;
END;

